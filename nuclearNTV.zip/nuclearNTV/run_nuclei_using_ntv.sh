#!/bin/bash

# Colors for the dashboard
RESET="\e[0m"
BOLD="\e[1m"
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
BLUE="\e[34m"
MAGENTA="\e[35m"

# Define file names
TEMPLATES_FILE="templates.txt"
INFO_SEVERITY_FILE="infoSeverityTemplates.txt"
INFO_LESS_FILE="infoLessTemplates.txt"
TEMPLATES_DIR="$HOME/nuclei-templates"

# Function to display usage information
usage() {
    echo -e "${RED}[ERROR] ${RESET}Usage: $0 [-directory /path/to/nuclei-templates]"
    echo -e "${GREEN}[INFO] Example: $0 -directory $HOME/nuclei-templates${RESET}"
    exit 1
}

# Parse command-line options
while getopts ":d:" opt; do
    case ${opt} in
        d ) # Directory path
            TEMPLATES_DIR=$OPTARG
            ;;
        \? ) # Invalid option
            usage
            ;;
        : ) # Missing argument
            echo -e "${RED}Invalid option: -$OPTARG requires an argument.${RESET}"
            usage
            ;;
    esac
done
shift $((OPTIND -1))

# Ensure the templates directory is provided and exists
if [ -z "$TEMPLATES_DIR" ]; then
    echo -e "${RED}[ERROR] ${RESET}-directory option is required."
    usage
fi

if [ ! -d "$TEMPLATES_DIR" ]; then
    echo -e "${RED}[ERROR] ${RESET}Directory $TEMPLATES_DIR does not exist."
    exit 1
fi

# Prompt user for nuclei version
read -p "[+] Enter the Nuclei version (e.g., 10.0.0, 9.9.2): " NUCLEI_VERSION

# Validate input for Nuclei version (basic check)
if [[ ! "$NUCLEI_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "${RED}[-] Error: ${RESET}Invalid version format. Please use the format X.Y.Z."
    exit 1
fi

# Run nuclei command to generate templates.txt
echo -e "${GREEN}[+] ${RESET}Generating templates.txt using nuclei version $NUCLEI_VERSION..."
nuclei -ntv "v$NUCLEI_VERSION" -tl -silent > "$TEMPLATES_FILE"

# Update file paths in templates.txt
echo -e "${GREEN}[+] ${RESET}Updating file paths in templates.txt..."
sed -i "s|^|$TEMPLATES_DIR/|" "$TEMPLATES_FILE"

# Ensure templates.txt exists and is not empty
if [ ! -s "$TEMPLATES_FILE" ]; then
    echo -e "${RED}[-] Error: ${RESET}$TEMPLATES_FILE is empty or not created."
    exit 1
fi

# Extract severities and filter info severity
echo -e "${GREEN}[+] ${RESET}Processing templates to extract severities..."
> "$INFO_SEVERITY_FILE"

while IFS= read -r template; do
    # Check if the file exists and is readable
    if [ ! -r "$template" ]; then
        echo -e "${YELLOW}[-] Warning: ${RESET}Cannot read file $template."
        continue
    fi

    # Extract severity from the template file
    severity=$(grep -i "severity:" "$template" 2>/dev/null | awk '{print $2}' | tr -d '[:space:]')

    # If severity is 'info', write to infoSeverityTemplates.txt
    if [ "$severity" == "info" ]; then
        echo "$template" >> "$INFO_SEVERITY_FILE"
    fi
done < "$TEMPLATES_FILE"

# Create infoLessTemplates.txt by removing info severity templates from templates.txt
echo -e "${GREEN}[+] ${RESET}Creating infoLessTemplates.txt..."
grep -v -F -f "$INFO_SEVERITY_FILE" "$TEMPLATES_FILE" > "$INFO_LESS_FILE"

# Clean up files
rm -rf $INFO_SEVERITY_FILE $TEMPLATES_FILE
mv $INFO_LESS_FILE templates_$NUCLEI_VERSION.txt

echo -e "\n${GREEN}[+] Templates File  : ${YELLOW}templates_$NUCLEI_VERSION.txt${RESET}"
echo -e "${GREEN}[+] Templates Found : ${YELLOW}$(wc -l < templates_$NUCLEI_VERSION.txt)${RESET}"
echo -e "${GREEN}[+] Found Domain    :${RESET} $(wc -l < domain.txt)"
echo -e "${GREEN}[+] Running         :${RESET} Subfinder on domain.txt"
subfinder -dL domain.txt -o subdomain.txt -silent > /dev/null
echo -e "${GREEN}[+] Found Subdomain :${RESET} $(wc -l < subdomain.txt)"

echo -e "${GREEN}[+] Running         :${RESET} HTTPX on subdomain.txt"
httpx -l subdomain.txt -o subdomains.txt -silent > /dev/null
echo -e "${GREEN}[+] Alive Subdomain :${RESET} $(wc -l < subdomains.txt)"
rm subdomain.txt

echo -e "\n${GREEN}[+] Running Nuclei Scanning:\n\n${RESET}"
# Run the nuclei scanning with the generated template file
./nuclei.sh --templates_file templates_$NUCLEI_VERSION.txt
