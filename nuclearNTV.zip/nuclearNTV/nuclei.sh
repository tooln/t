#!/bin/bash

# Colors for the dashboard
RESET="\e[0m"
BOLD="\e[1m"
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[33m"
CYAN="\e[36m"
BLUE="\e[34m"
MAGENTA="\e[35m"

# Function to display current time in GMT+6
current_time() {
    date +"%Y-%m-%d %H:%M:%S" -d 'TZ="Asia/Dhaka"'
}

# Check if the correct argument is passed
if [[ $# -ne 2 || "$1" != "--templates_file" ]]; then
    echo -e "${RED}[ERROR] Usage: ./nuclei.sh --templates_file templates.txt${RESET}"
    exit 1
fi

# Get the template file from the argument
TEMPLATES_FILE=$2
touch output.txt

# Ensure templates file exists
if [[ ! -f "$TEMPLATES_FILE" ]]; then
    echo -e "${RED}[ERROR] Templates file '$TEMPLATES_FILE' not found.${RESET}"
    exit 1
fi

# Get total templates count
total_templates=$(wc -l < "$TEMPLATES_FILE")

# Function to display the dashboard before running the Nuclei command
display_dashboard() {
    local processed=$1
    local remaining=$2
    
    clear # Optional: Clears the terminal for a fresh dashboard update

    echo -e "${CYAN}${BOLD}===========================[ NUCLEI SCANNER DASHBOARD ]===========================${RESET}"
    echo -e "${CYAN}${BOLD}Current Time               : ${MAGENTA}$(current_time)${RESET}"
    echo -e "${CYAN}${BOLD}Total Subdomains           : ${MAGENTA}$(wc -l < subdomains.txt)${RESET}"
    echo -e "${CYAN}${BOLD}Total Templates            : ${MAGENTA}$total_templates${RESET}"
    echo -e "${CYAN}${BOLD}Processed                  : ${MAGENTA}$processed${RESET}"
    echo -e "${CYAN}${BOLD}Remaining                  : ${MAGENTA}$remaining${RESET}"
    echo -e "${CYAN}${BOLD}Found                      : ${MAGENTA}$(wc -l < output.txt)${RESET}"
    echo -e "${CYAN}${BOLD}==================================================================================${RESET}"
}

# Process the templates file
counter=0
while [[ -s "$TEMPLATES_FILE" ]]; do
    # Get the first line from the template file using head
    template=$(head -n 1 "$TEMPLATES_FILE")

    # Display the dashboard before running Nuclei
    remaining=$((total_templates - counter))
    display_dashboard $counter $remaining

    # Run Nuclei command with the template
    echo -e "${GREEN}${BOLD}[INFO] Processing Template : ${MAGENTA}$template${RESET}"
    echo -e "${GREEN}${BOLD}[INFO] Template Severity   : ${MAGENTA}$(grep -i "severity:" $template 2>/dev/null | awk '{print $2}' | tr -d '[:space:]')${RESET}"
    nuclei -l subdomains.txt -t "$template" -bs 200 | tee -a output.txt

    # Remove the processed line from the file using awk
    awk 'NR > 1' "$TEMPLATES_FILE" > temp && mv temp "$TEMPLATES_FILE"
    
    # Increment counter
    counter=$((counter + 1))
done

# Final message after completion
echo -e "${CYAN}${BOLD}====================[ NUCLEI SCANNER PROCESS COMPLETED ]====================${RESET}"
echo -e "${GREEN}[INFO] All templates processed successfully.${RESET}"
